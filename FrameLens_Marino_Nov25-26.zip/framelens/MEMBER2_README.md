# FrameLens — Member 2 | November 25–26

Scope: Python environment setup, pipeline structure, majority baseline and TF-IDF + Logistic Regression, and first metrics. Based on pages 5, 7–9 of the execution plan. The original `Clean.ipynb`, `explore.py` and four CSV files are unchanged.

## 1. Windows setup (PowerShell)

Open the project folder in VS Code. Open its terminal. Use Python 3.13 (the experiment was tested on 3.13.5):

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-ml.txt
.\.venv\Scripts\python.exe -m src.train
```

If `py -3.13` is unavailable, install Python 3.13 or use `python -m venv .venv` if `python --version` reports 3.13. The explicit virtual environment executable avoids PowerShell activation-policy issues. Select the `.venv` Python interpreter / kernel in VS Code when opening the notebook. Alternatively launch Jupyter using ` .\.venv\Scripts\python.exe -m notebook` (without the leading space).

The separate `requirements-ml.txt` avoids overwriting Member 3's planned shared `requirements.txt`. Coordinate dependency versions before merging. A Windows virtual environment is not bundled; it must be created locally. Training and notebook were tested in a Linux Python environment, not on the user's Windows computer.

## 2. What to open first

`notebooks/03_model_training.ipynb` contains the executed baseline walkthrough. It imports functions from the reusable source files rather than duplicating the experiment. Read `src/train.py` and `src/evaluate.py` for their implementations. Run All in the notebook to reproduce the logged outputs, or use the command above. Both approaches write the same artifact paths.

## 3. Data and methodology

- Use the existing 2,938 training rows; `model_text` is the input, `label` is the target (0 non-biased, 1 biased). `news_link` is only used to group folds, never as a model feature.
- Use five stratified article-grouped validation folds within `train.csv`, identical for both models (seed 42). Verify no shared group IDs between fitting and validation portions. Unknown URLs were assigned synthetic unique IDs by Member 1; grouping cannot guarantee separation of their true source articles.
- Majority baseline learns the most frequent class in each fitting fold; it ignores the sentence contents.
- Logistic Regression uses a scikit-learn Pipeline with word TF-IDF (unigrams and bigrams, default token pattern, no stop-word removal), then LogisticRegression (C=1, lbfgs, max_iter=1000). These are initial settings, not tuned; Member 1 can finalize TF-IDF config on November 27. Default word tokenization does not directly encode punctuation and one-character tokens; negation words such as 'not' are retained.
- Fit both steps only on each fitting fold; use the corresponding unseen validation fold to score. Macro F1 is primary, with accuracy and per-class precision/recall/F1 also recorded. Scores are unweighted fold means; standard deviation uses ddof=0. No final holdout metrics or hyperparameter search today.
- Train a separate preliminary Logistic Regression pipeline on all training rows for demo use. It is NOT the final best model. Input to the saved pipeline is normalized `model_text`; for raw strings use `preprocess_text` from `src.train`, matching Member 1's function. Later coordinate a single shared preprocessing module with Member 1 and Member 3.

## 4. Actual preliminary results (grouped training CV)

| Model | Accuracy | Macro F1 |
|---|---:|---:|
| Majority baseline | 0.5071 | 0.3365 |
| TF-IDF + Logistic Regression | 0.7012 | 0.7006 |

These values are validation estimates, not final test results. The 735-row `data/test.csv` is unchanged and not read by the training code. Predictions indicate language patterns associated with the dataset's bias labels, not factual truth or political ideology.

## 5. New files

- `requirements-ml.txt` — tested direct dependency versions.
- `src/train.py` — data loading, baseline pipelines, grouped CV, artifact saving and matching raw-text normalization.
- `src/evaluate.py` — reusable classification metrics.
- `notebooks/03_model_training.ipynb` — executed learning notebook.
- `reports/baseline_results.csv` — mean validation metrics by model.
- `reports/baseline_fold_metrics.csv` — validation metrics and counts for each fold.
- `reports/baseline_config.json` — experiment configuration, seed, training file hash and versions.
- `models/baseline_logistic_regression.joblib` — preliminary fitted pipeline (load only trusted Joblib files, with matching package versions).

## 6. Git handoff

This ZIP does not contain `.git` or Jupyter checkpoints. Keep your existing cloned repository. Copy the new files into that clone, checking for team changes and retaining all original data and notebook files. Do not replace the clone or its `.git` folder. Run `git status`; use your `ml-models` branch to commit the new source, notebook, reports, and instructions. Coordinate with the team before committing the binary model; it can be regenerated with `python -m src.train`. Avoid committing `.venv` or `__pycache__`.

## 7. Not part of this delivery

November 27: Multinomial Naive Bayes, Linear SVM, Random Forest. November 28: hyperparameter tuning. November 29: final holdout evaluation. November 30: `best_model.joblib`. The Streamlit app, shared repository configuration and final prediction contract remain Member 3's tasks. The original unfinished `explore.py` is preserved, not used by ML code.
